using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class LogPage : BasePage
{
	public LogPage(LogPageViewModel vm)
	{
		InitializeComponent();
		BindingContext = vm;
	}
}