﻿using BigBazar.ViewModels;

namespace BigBazar.Views
{
    public partial class MainPage : BasePage
    {
        public MainPage(MainPageViewModel viewModel)
        {
            InitializeComponent();
            BindingContext = viewModel;
        }


    }

}
