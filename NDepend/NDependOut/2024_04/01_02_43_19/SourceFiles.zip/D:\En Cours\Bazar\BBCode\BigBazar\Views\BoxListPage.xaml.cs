#nullable disable
using BigBazar.Messages;
using BigBazar.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Microsoft.Maui.Controls.PlatformConfiguration;
using Microsoft.Maui.Platform;

namespace BigBazar.Views;

public partial class BoxListPage : BasePage
{
    public BoxListPage(BoxListPageViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }

    private void Switch_Toggled(object sender, ToggledEventArgs e)
    {
        searchBar.Text = "";
    }
}