using System.ComponentModel;
using BigBazar.Services;
using CommunityToolkit.Mvvm.ComponentModel;

namespace BigBazar.Views;

public partial class AboutPage : BasePage  
{
	public AboutPage()
	{
		InitializeComponent();
		BindingContext = this;
	}

    public AboutPage(IVersionService version) : this()
    {
   		Title = version.Title;
		Version = version.Version;

    }

	// expose a property for the current version of the app

	public string Version { get; set; }
	
}