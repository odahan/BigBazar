#nullable disable
using BigBazar.Messages;
using BigBazar.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Microsoft.Maui.Controls.PlatformConfiguration;
using Microsoft.Maui.Platform;

namespace BigBazar.Views;

public partial class BoxListPage : BasePage
{
    BoxListPageViewModel viewModel;
    public BoxListPage(BoxListPageViewModel viewModel)
    {
        InitializeComponent();
        this.viewModel = viewModel;
        BindingContext = viewModel;
    }
    
    override protected void OnAppearing()
    {
        base.OnAppearing();
        viewModel.InitPage();
    }

    private void Picker_SelectedIndexChanged(object sender, EventArgs e)
    {
        searchBar.Text = "";
    }
}