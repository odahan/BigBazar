#nullable disable
using BigBazar.Services;
using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class CategoryPage : BasePage
{
	public CategoryPage(IViewModelFactory viewModelFactory)
	{
        InitializeComponent();
		BindingContext = viewModelFactory.Create<CategoryPageViewModel>();
    }
    

}