﻿namespace BigBazar.Utils
{
    public enum BoxSearchMode
    {
        None = 0,
        Description,
        Category,
        Area
    }
}