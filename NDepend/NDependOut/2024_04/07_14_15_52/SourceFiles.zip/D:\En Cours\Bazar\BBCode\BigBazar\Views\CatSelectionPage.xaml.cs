#nullable disable
using BigBazar.Services;
using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class CatSelectionPage : BasePage
{
	public CatSelectionPage(IViewModelFactory viewModelFactory)
	{
        InitializeComponent();
		BindingContext = viewModelFactory.Create<CatSelectionPageViewModel>();
    }
    
}