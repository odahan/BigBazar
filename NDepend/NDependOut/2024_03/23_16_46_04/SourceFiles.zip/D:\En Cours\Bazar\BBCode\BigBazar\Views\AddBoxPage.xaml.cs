﻿using BigBazar.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigBazar.Views;

public partial class AddBoxPage : BasePage
{
    public AddBoxPage(AddBoxPageViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}