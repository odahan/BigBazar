﻿#nullable disable
using BigBazar.Messages;
using BigBazar.Models;
using BigBazar.Services;
using CommunityToolkit.Diagnostics;
using CommunityToolkit.Maui.Core.Extensions;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using System.Collections.ObjectModel;
using BigBazar.Controls;
using System.Runtime.CompilerServices;

namespace BigBazar.ViewModels;

public partial class BoxPageViewModel : BaseViewModel, IQueryAttributable
{

    public BoxPageViewModel(IDataService service) : base()
    {
        Guard.IsNotNull(service);
        isCtorTime = true;
        Title = "Box";
        dataService = service;
        WeakReferenceMessenger.Default.Register<PastilleMessage>(this, OnPastilleMessageReceived);
        WeakReferenceMessenger.Default.Register<CatSelectedMessage>(this, OnCatSelectedMessageReceived);
        WeakReferenceMessenger.Default.Register<BoxPageViewModel,
             AlreadySelectedCatsRequestMessage>(this, (r, m) => { if (!m.HasReceivedResponse) m.Reply(getSelectedCatId()); });
    }

    private List<int> getSelectedCatId()
    {
        // create a list of the selected cat ids
        var selectedCats = boxCats.Select(c => c.IdCat).ToList();
        return selectedCats;
    }


    private bool isCtorTime = false;

    [ObservableProperty]
    [NotifyPropertyChangedFor("Description")]
    private Box currentBox;

    [ObservableProperty]
    private string description;

    [ObservableProperty]
    private bool isModified;

    private readonly IDataService dataService;

    private List<BoxCatForDisplay> boxCats;

    public async void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        if (!isCtorTime) return;
        isCtorTime = false;
        Guard.IsNotNull(query);
        var id = Convert.ToInt32(query["boxid"]);
        CurrentBox = await dataService.GetBoxByIdAsync(id);
        boxCats = (await dataService.GetCatsForBoxId(id));
        Description = CurrentBox.Description;
        IsModified = false;
        WeakReferenceMessenger.Default.Send(new BoxPageRebuildCatListMessage() { Tag = boxCats });
    }

    partial void OnDescriptionChanged(string value)
    {
        IsModified = true;
        CurrentBox.Description = value;
    }

    private readonly object locker = new object();
    private bool working = false;
    private async void OnPastilleMessageReceived(object recipient, PastilleMessage message)
    {
        lock (locker)
        {
            if (working)
            {
                return;
            }
            working = true;
        }
        try
        {
            Guard.IsNotNull(message);
            var payload = message.Payload;
            var payloadIconKind = message.Kind;
            switch (payloadIconKind)
            {
                case PayloadKind.Add:
                    // Add a new BoxCat to the list
                    // call to the catselection page. 
                    await Shell.Current.GoToAsync("CatSelection");
                    await Task.Delay(400);
                    break;
                case PayloadKind.Delete:
                    var modified = false;
                    for (var i = boxCats.Count - 1; i >= 0; i--)
                    {
                        if (payload != null && boxCats[i].IdBoxCat == (int)payload)
                        {
                            var boxCatId = (int)payload;
                            boxCats.RemoveAt(i);
                            await dataService.DeleteBoxCatAsync(boxCatId);
                            modified = true;
                            break;
                        }
                    }
                    if (modified)
                    {
                        boxCats = (await dataService.GetCatsForBoxId(CurrentBox.Id));
                        WeakReferenceMessenger.Default.Send(new BoxPageRebuildCatListMessage() { Tag = boxCats });
                    }
                    break;
                default:
                    break;
            }
        }
        finally
        {
            lock (locker) working = false;
        }
    }

    [RelayCommand]
    public void Save()
    {
        IsBusy = true;
        try
        {
            try
            {
                Guard.IsNotNull(dataService);
                dataService.SaveBoxAsync(CurrentBox);
                WeakReferenceMessenger.Default.Send(new BoxListDataModifiedMessage { ViewModelName = nameof(BoxListPageViewModel), MessageData = new Tuple<Box, int>(CurrentBox, currentBox.Id) });
            }
            finally
            {
                IsBusy = false;
            }
            IsModified = false;
        }
        catch (Exception ex)
        {
            Logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error saving Box entity: {ex.Message}");
            IsModified = false;
        }
    }

    [RelayCommand]
    private async void DisplayBoxPhotos()
    {
        await Shell.Current.GoToAsync($"detail/Gallery?PhotoNumber={CurrentBox.Number}", true);
    }

    private async void OnCatSelectedMessageReceived(object recipient, CatSelectedMessage message)
    {
        Guard.IsNotNull(message);
        IsBusy = true;
        try
        {
            var selectedCats = message.SelectedCategories;
            foreach (var cat in selectedCats)
            {
                var b = boxCats.Any(c => c.IdBox == currentBox.Id && c.IdCat == cat.Id);
                if (b) continue;
                var bxc = new BoxCat() { CatId = cat.Id, BoxId = CurrentBox.Id };
                var id = await dataService.SaveBoxCatAsync(bxc);
                var bcf = new BoxCatForDisplay(id, cat.Id, CurrentBox.Id, cat.Name);

                boxCats.Add(bcf);
            }
        }
        finally
        {
            IsBusy = false;
        }
        // send a message to rebuild the visual list
        // sort boxcats by catname   
        boxCats = boxCats.OrderBy(c => c.CatName).ToList();

        WeakReferenceMessenger.Default.Send(new BoxPageRebuildCatListMessage() { Tag = boxCats });
    }
}