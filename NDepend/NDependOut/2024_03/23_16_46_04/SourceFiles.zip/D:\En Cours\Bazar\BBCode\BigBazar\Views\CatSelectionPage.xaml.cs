#nullable disable
using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class CatSelectionPage : BasePage
{
	public CatSelectionPage(CatSelectionPageViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
}