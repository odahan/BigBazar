﻿#nullable disable
using Microsoft.Maui.Controls;
using System;

namespace BigBazar.Controls;

public class ZoomableImage : Image
{
    double currentScale = 1, startScale = 1, xOffset = 0, yOffset = 0;
    const double MinScale = 1; // Limite de zoom minimale pour éviter de rendre l'image trop petite.
    const double MaxScale = 20; // Limite de zoom maximale pour éviter un agrandissement excessif.
    double initialWidth, initialHeight; // Utilisé pour le double-tap reset.

    public ZoomableImage()
    {
        // Pinch Gesture
        var pinchGesture = new PinchGestureRecognizer();
        pinchGesture.PinchUpdated += OnPinchUpdated;
        this.GestureRecognizers.Add(pinchGesture);

        // Pan Gesture
        var panGesture = new PanGestureRecognizer();
        panGesture.PanUpdated += OnPanUpdated;
        this.GestureRecognizers.Add(panGesture);

        // Double Tap Gesture
        var tapGesture = new TapGestureRecognizer { NumberOfTapsRequired = 2 };
        tapGesture.Tapped += OnDoubleTapped;
        this.GestureRecognizers.Add(tapGesture);

        this.SizeChanged += (sender, args) =>
        {
            initialWidth = this.Width;
            initialHeight = this.Height;
        };
    }

    void OnPinchUpdated(object sender, PinchGestureUpdatedEventArgs e)
    {
        if (e.Status == GestureStatus.Started)
        {
            startScale = currentScale;
        }
        else if (e.Status == GestureStatus.Running)
        {
            var tempScale = currentScale + (e.Scale - 1) * startScale;
            currentScale = Math.Max(MinScale, Math.Min(tempScale, MaxScale));

            // Apply the scale factor
            this.Scale = currentScale;
        }
        else if (e.Status == GestureStatus.Completed)
        {
            startScale = currentScale;
        }
    }

    void OnPanUpdated(object sender, PanUpdatedEventArgs e)
    {
        if (e.StatusType == GestureStatus.Running)
        {
            var totalX = xOffset + e.TotalX;
            var totalY = yOffset + e.TotalY;

            // Ensure the image remains within screen bounds
            this.TranslationX = Math.Max(Math.Min(0, totalX), -Math.Abs(this.Width * currentScale - this.Width));
            this.TranslationY = Math.Max(Math.Min(0, totalY), -Math.Abs(this.Height * currentScale - this.Height));
        }
        else if (e.StatusType == GestureStatus.Completed)
        {
            xOffset = this.TranslationX;
            yOffset = this.TranslationY;
        }
    }

    void OnDoubleTapped(object sender, EventArgs e)
    {
        // Reset scale and position
        this.Scale = MinScale;
        this.TranslationX = 0;
        this.TranslationY = 0;
        currentScale = MinScale;
        xOffset = 0;
        yOffset = 0;
    }
}
