﻿#nullable disable
using System.Collections.ObjectModel;
using System.Reflection;
using System.Runtime.CompilerServices;
using BigBazar.Models;
using BigBazar.Services;
using BigBazar.Views;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;


namespace BigBazar.ViewModels;

public partial class GalleryPageViewModel : BaseViewModel
{
    public GalleryPageViewModel(IDataService data) : base()
    {
        Title = "Gallery";
        Photos = [];
        photosDirectory = data.PhotosDirectory;
        screenWidth = DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density;
        LoadPhotos();
    }

    [ObservableProperty]
    private ObservableCollection<Photo> photos;

    private readonly string photosDirectory;

    [ObservableProperty]
    private double screenWidth;
    private void LoadPhotos()
    {
        IsBusy = true;
        try
        {
            var imageFiles =Directory.GetFiles(photosDirectory, "*.jpg", SearchOption.AllDirectories).OrderBy(f => f);

            foreach (var file in imageFiles)
            {
                Photos.Add(new Photo(file));
            }
        }
        catch (Exception ex)
        {
            Logger.LogErrorAsync(Services.AppLogger.LogLevel.Error, "Error loading photo names \n"+ex.Message);
            Photos = [];
        }
        finally
        {
            IsBusy = false;
        }
    }

    [ObservableProperty]
    private bool isGoingToPhotoDetail;

    [RelayCommand]
    private async Task ItemTapped(Photo photo)
    {
        IsGoingToPhotoDetail = true;
        var photoPage = new FullScreenPhotoPage(photo.ImagePath,new DeviceOrientationService(),false);
        await Shell.Current.Navigation.PushAsync(photoPage);
        IsGoingToPhotoDetail = false;
    }
}