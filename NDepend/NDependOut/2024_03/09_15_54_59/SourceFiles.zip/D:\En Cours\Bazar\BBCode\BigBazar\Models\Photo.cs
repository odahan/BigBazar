﻿#nullable disable
using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.IO;
using System.Text.RegularExpressions;

namespace BigBazar.Models;

[ObservableObject]
public partial class Photo 
{
    public Photo()
    {
    }

    public Photo(string imagePath) : this()
    {
        ImagePath = imagePath;
        DisplayName = ExtractDisplayName(imagePath);
    }

    [ObservableProperty]
    private string imagePath;
    
    [ObservableProperty]
    private string displayName;

    public static string ExtractDisplayName(string imagePath)
    {
        var fileName = Path.GetFileNameWithoutExtension(imagePath);
        var regex = new Regex(@"box(\d+)_(\d+)");
        var match = regex.Match(fileName);

        if (!match.Success) return fileName;
        var boxNumber = match.Groups[1].Value;
        var photoNumber = match.Groups[2].Value;
        return $"{boxNumber}/{photoNumber}";

    }
}