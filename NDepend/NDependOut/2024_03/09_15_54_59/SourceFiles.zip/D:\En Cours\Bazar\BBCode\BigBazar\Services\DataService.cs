﻿#nullable disable
using BigBazar.Models;
using SQLite;
using SkiaSharp;
using CommunityToolkit.Diagnostics;

namespace BigBazar.Services;


public class DataService : IDataService
{
    #region private fields
    private const string DatabaseName = "BigBazar.db3";
    private const string DatabaseNameBackup = "BigBazar.Bak.db3";
    private SQLiteAsyncConnection database;
    private readonly string dbPath;
    private readonly IAppLogger logger;
    private readonly string photosDirectory;
    // ReSharper disable once NotAccessedField.Local
    private readonly IPathService imagesPathService;
    private IDialogService dialogService;
    #endregion

    #region public fields, consts & properties
    public const SQLiteOpenFlags Flags =
        // open the database in read/write mode
        SQLiteOpenFlags.ReadWrite |
        // create the database if it doesn't exist
        SQLiteOpenFlags.Create |
        // enable multi-threaded database access
        SQLiteOpenFlags.SharedCache;

    public bool IsInitialized { get; private set; }

    public string PhotosDirectory => photosDirectory;

    #endregion

  
    #region Ctor
    public DataService(IAppLogger logger, IPathService imagesPathService, IDialogService dialog)
    {
        IsInitialized = false;
        this.imagesPathService = imagesPathService;
        this.logger = logger;
        dialogService = dialog;

        // Construct database path

        dbPath = Path.Combine(FileSystem.AppDataDirectory, DatabaseName);
        // ex: /data/user/0/com.companyname.bigbazar/files/BigBazar.db3
        // accessible avec Android Device Explorer dans Android Studio, répertoire data/data/com.companyname.bigbazar/files
        try
        {
            database = new SQLiteAsyncConnection(dbPath, Flags);
        }
        catch (Exception ex)
        {
            logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error SQLite initializing database: " + ex.Message);
            IsInitialized = false;
            return;
        }

        try
        {
            database.CreateTableAsync<Box>();
            database.CreateTableAsync<Category>();
            database.CreateTableAsync<BoxCat>();
        }
        catch (Exception ex)
        {
            logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error creating tables: " + ex.Message);
            IsInitialized = false;
            return;
        }


        photosDirectory = Path.Combine(FileSystem.AppDataDirectory, "Photos");
        //logger.LogErrorAsync(AppLogger.LogLevel.Information, "Database Service initialized"+new string('-',30));
        IsInitialized = true;
    }

    public async Task CreateTablesAsync()
    {
        IsInitialized = false;
        try
        {
            await database.CreateTableAsync<Box>();
            await database.CreateTableAsync<Category>();
            await database.CreateTableAsync<BoxCat>();
            IsInitialized = true;
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error creating tables: " + ex.Message);
            IsInitialized = false;
        }

    }
    #endregion

    #region Box operations
    // Save or update a Box
    public async Task<int> SaveBoxAsync(Box box)
    {
        Guard.IsNotNull(box);
        int id;
        try
        {
            if (box.Id != 0)
            {
                await database.UpdateAsync(box);
                id = box.Id;
            }
            else
            {
                id = await database.InsertAsync(box);
            }
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error saving box: " + ex.Message);
            return -1;
        }
        return id;
    }

    // Delete a Box and related BoxCats
    public async Task<int> DeleteBoxAsync(int boxId)
    {
        Guard.IsGreaterThan(boxId, 0);
        try
        {
            await database.Table<BoxCat>().DeleteAsync(bc => bc.BoxId == boxId);
            return await database.DeleteAsync<Box>(boxId);
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error deleting box: " + ex.Message);
            return -1;
        }
    }

    public async Task<bool> DeleteBoxByBoxNumber(int boxNumber)
    {
        Guard.IsGreaterThan(boxNumber, 0);
        try
        {
            var box = await GetBoxByNumberAsync(boxNumber);
            if (box != null)
            {
                await DeleteAllPhotosForBoxAsync(box.Id);
                await database.Table<BoxCat>().DeleteAsync(bc => bc.BoxId == box.Id);
                await database.DeleteAsync<Box>(box.Id);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error deleting box by number: " + ex.Message);
            return false;
        }
    }

    // Retrieve all Boxes
    public async Task<List<Box>> GetBoxesAsync()
    {
        try
        {
            return await database.Table<Box>().OrderBy((b)=>b.Number).ToListAsync();
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error retrieving boxes: " + ex.Message);
            return [];
        }
    }

    // Retrieve all Boxes matching a search text
    public async Task<List<Box>> SearchBoxesDescAsync(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return await GetBoxesAsync();
        try
        {
            var boxes = await database.Table<Box>().ToListAsync();
            return boxes.Where(box => 
                         box.Description.Contains(text,StringComparison.OrdinalIgnoreCase))
                        .OrderBy((b)=>b.Number).ToList();
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error searching boxes on text [{text}]: " + ex.Message);
            return [];
        }

    }

    // Retrieve a Box by ID
    public async Task<Box> GetBoxByIdAsync(int id)
    {
        Guard.IsGreaterThan(id, 0);
        try
        {
            return await database.Table<Box>().Where(x => x.Id == id).FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error retrieving box by ID: " + ex.Message);
            return null;
        }
    }

    // Retrieve a Box by number
    public async Task<Box> GetBoxByNumberAsync(int id)
    {
        Guard.IsGreaterThan(id, 0);
        try
        {
            return await database.Table<Box>().Where(x => x.Number == id).FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error retrieving box by number: " + ex.Message);
            return null;
        }
    }

    public async Task<int> GetLastBoxNumberAsync()
    {
        try
        {
            var lastBox = await database.Table<Box>().OrderByDescending(b => b.Number).FirstOrDefaultAsync();
            return lastBox?.Number ?? 1;
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error retrieving last box number: " + ex.Message);
            return -1;
        }
    }

    public async Task<int> GetNewBoxNumber()
    {
        try
        {
            var firstMissing = await GetFirstMissingBoxNumbersAsync();
            if (firstMissing > 0)
            {
                return firstMissing;
            }

            var lastBox = await database.QueryAsync<int>("SELECT Number FROM Boxes ORDER BY Number DESC");
            var lastBoxNumber = lastBox.FirstOrDefault();
            return lastBoxNumber + 1;
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error retrieving first available box number: " + ex.Message);
            return -1;
        }
    }

    public async Task<int> GetFirstMissingBoxNumbersAsync()
    {
        try
        {
            var allNumbers = await database.QueryAsync<int>("SELECT Number FROM Boxes ORDER BY Number ASC");
            int? firstMissingNumber;

            for (var i = 0; i < allNumbers.Count - 1; i++)
            {
                if (allNumbers[i] + 1 != allNumbers[i + 1])
                {
                    firstMissingNumber = allNumbers[i] + 1;
                    return firstMissingNumber.Value;
                }
            }
            return -1;
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error searching first missing Box numbers: " + ex.Message);
            return -1;
        }
    }

    public async Task<List<int>> GetAllActiveBoxNumbers()
    {
        return await database.QueryAsync<int>("SELECT Number FROM Boxes ORDER BY Number ASC");
    }

    #endregion

    #region Category operations
    // Save or update a Category
    public async Task<int> SaveCategoryAsync(Category category)
    {
        Guard.IsNotNull(category);
        if (category.Id > 0)
        {
            try
            {
                await database.UpdateAsync(category);
            }
            catch (Exception ex)
            {
                await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error updating category: " + ex.Message);
                return -1;
            }
        }
        else
        {
            try
            {
                return await database.InsertAsync(category);
            }
            catch (Exception ex)
            {
                await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error inserting category: " + ex.Message);
                return -1;
            }
        }
        return -1;
    }

    public async Task<int> HowMuchTimesCategoryIsUsed(int categoryId)
    {
        Guard.IsGreaterThan(categoryId, 0);
        try
        {
            return await database.Table<BoxCat>().CountAsync(bc => bc.CatId == categoryId);
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error counting category usage: " + ex.Message);
            return -1;
        }
    }   

    // Delete a Category and related BoxCats
    public async Task<int> DeleteCategoryAsync(int categoryId)
    {
        Guard.IsGreaterThan(categoryId, 0);
        try
        {
            await database.Table<BoxCat>().DeleteAsync(bc => bc.CatId == categoryId);
            return await database.DeleteAsync<Category>(categoryId);
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error deleting category: " + ex.Message);
            return -1;
        }
    }

    // Retrieve all Categories
    public async Task<List<Category>> GetCategoriesAsync()
    {
        try
        {
            return await database.Table<Category>().OrderBy((c)=>c.Name).ToListAsync();
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error retrieving categories: " + ex.Message);
            return [];
        }
    }

    // Retrieve a Category by ID
    public async Task<Category> GetCategoryByIdAsync(int id)
    {
        Guard.IsGreaterThan(id, 0);
        try
        {
            return await database.Table<Category>().Where(x => x.Id == id).FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error retrieving category by ID: " + ex.Message);
            return null;
        }
    }
    #endregion

    #region BoxCat operations
    
    // save or update a BoxCat relationship 
    public async Task<int> SaveBoxCatAsync(BoxCat boxCat)
    {
        Guard.IsNotNull(boxCat);
        if (boxCat.Id != 0)
        {
            try
            {
                await database.UpdateAsync(boxCat);
                return boxCat.Id;
            }
            catch (Exception ex)
            {
                await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error updating BoxCat: " + ex.Message);
                return -1;
            }
        }
        else
        {
            try
            {
                await database.InsertAsync(boxCat);
                return boxCat.Id;
            }
            catch (Exception ex)
            {
                await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error inserting BoxCat: " + ex.Message);
                return -1;
            }
        }
    }
    
    // Add a new BoxCat relationship
    public async Task<int> AddBoxCatAsync(BoxCat boxCat)
    {
        Guard.IsNotNull(boxCat);
        try
        {
            await database.InsertAsync(boxCat);
            return boxCat.Id;
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error inserting BoxCat: " + ex.Message);
            return -1;
        }
    }

    // Delete a BoxCat relationship
    public async Task<int> DeleteBoxCatAsync(int boxCatId)
    {
        Guard.IsGreaterThan(boxCatId, 0);
        try
        {
            return await database.DeleteAsync<BoxCat>(boxCatId);
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error deleting BoxCat: " + ex.Message);
            return -1;
        }
    }

    // Retrieve all BoxCat relationships
    public async Task<List<BoxCat>> GetBoxCatsAsync()
    {
        try
        {
            return await database.Table<BoxCat>().ToListAsync();
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error retrieving BoxCat relationships: " + ex.Message);
            return [];
        }
    }

    public async Task<List<BoxCatForDisplay>> GetCatsForBox(int boxId)
    {
        Guard.IsGreaterThan(boxId, 0);
        try
        {
            var boxCats = await database.Table<BoxCat>().Where(bc => bc.BoxId == boxId).ToListAsync();
            var cats = new List<BoxCatForDisplay>();
            foreach (var boxCat in boxCats)
            {
                var cat = await GetCategoryByIdAsync(boxCat.CatId);
                if (cat != null)
                {
                    cats.Add(new BoxCatForDisplay(boxCat.Id, boxCat.CatId, boxCat.BoxId, cat.Name));
                }
            }
            return cats.OrderBy((c)=>c.CatName).ToList();
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error retrieving categories for box Id {boxId}: " + ex.Message);
            return [];
        }
    }
    #endregion

    #region Backup database
    // Backup database and send it via email
    public async Task<bool> BackupDatabaseAsync()
    {
        if (!Email.Default.IsComposeSupported)
        {
            _ = logger.LogErrorAsync(AppLogger.LogLevel.Error, "Email is not supported on this device");
            await dialogService.ShowMessage("Error", "Email is not supported on this device", "Ok");
            return false;
        }

        if (database != null)
        {
            await database.CloseAsync();
        }

        return await Task.Run(async () =>
        {

            try
            {
                // Make sure that all database operations are completed before continuing.
                var dbCopy = Path.Combine(FileSystem.AppDataDirectory, DatabaseNameBackup);
                // Copy the database file to the backup file

                try
                {
                    File.Copy(dbPath, dbCopy, true);
                }
                catch (Exception ex)
                {
                    await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error creating backup file: " + ex.Message);
                    await dialogService.ShowMessage("Error creating backup file", ex.Message, "OK");
                    return false;
                }

                var emailMessage = new EmailMessage
                {
                    Subject = "Backup BigBazar database",
                    Body = "Backup BigBazar database performed on " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };
                emailMessage.To?.Add("odahan@gmail.com");

                // Attach the database file to the email.
                // Note: Make sure the file can be read and is not locked by any ongoing operation.
                emailMessage.Attachments?.Add(new EmailAttachment(dbCopy));

                // Use Email.ComposeAsync to prepare the email.
                await Email.Default.ComposeAsync(emailMessage);
                try
                {
                    database = new SQLiteAsyncConnection(dbPath, Flags);
                }
                catch (Exception ex)
                {
                    await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error SQLite creating database: " + ex.Message);
                    IsInitialized = false;
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error sending log backup mail: " + ex.Message);
                return false;
            }
        });
    }
    #endregion

    #region Photo operations

    private async Task<bool> CheckCameraPermission()
    {
        var status = await Permissions.CheckStatusAsync<Permissions.Camera>();

        if (status != PermissionStatus.Granted)
        {
            status = await Permissions.RequestAsync<Permissions.Camera>();
            _ = logger.LogErrorAsync(AppLogger.LogLevel.Error, "Camera permission denied: " + status.ToString());
            return false;
        }
        return true;
    }

    // Add a photo for a Box
    public async Task<string> AddPhotoForBoxAsync(int boxId)
    {
        Guard.IsGreaterThan(boxId, 0);
        // Check and request permission to use the camera
        var status = await CheckCameraPermission();
        if (!status) return null;
        //check if taking a photo is supported  
        if (!MediaPicker.IsCaptureSupported)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Taking a photo is not supported on this device.");
            return null;
        }

        // Take a photo
        try
        {
            var photo = await MediaPicker.CapturePhotoAsync();
            // ReSharper disable once ConditionIsAlwaysTrueOrFalse
            // ReSharper disable once HeuristicUnreachableCode
            if (photo == null) return null; // User canceled or capture failed

            // Determine the directory and file name for the photo
            Directory.CreateDirectory(photosDirectory); // Make sure the directory exists

            var photoFileName = $"box{boxId}_{await NextPhotoNumber(boxId)}.jpg";
            var photoPath = Path.Combine(photosDirectory, photoFileName);

            // Save the photo to the file system
            await using (var stream = await photo.OpenReadAsync())
            {
                await using (var newFile = File.OpenWrite(photoPath))
                {
                    await stream.CopyToAsync(newFile);
                }
            }

            return photoFileName;
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error taking photo: " + ex.Message);
            return null;
        }
    }

    private async Task<int> NextPhotoNumber(int boxId)
    {
        Guard.IsGreaterThan(boxId, 0);
        return await Task.Run(async () =>
        {
            try
            {
                var existingPhotos = Directory.EnumerateFiles(photosDirectory, $"box{boxId}_*.jpg");
                var maxNumber = existingPhotos.Select(file =>
                {
                    var fileName = Path.GetFileNameWithoutExtension(file);
                    if (int.TryParse(fileName.Split('_').Last(), out var number))
                    {
                        return number;
                    }
                    return 0;
                }).DefaultIfEmpty(0).Max();

                return maxNumber + 1;
            }
            catch (Exception ex)
            {
                await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error getting next photo number: " + ex.Message);
                return -1;
            }
        });
    }

    public async Task<bool> DeleteAllPhotosForBoxAsync(int boxId)
    {
        Guard.IsGreaterThan(boxId, 0);
        return await Task.Run(() =>
        {
            try
            {
                if (Directory.Exists(photosDirectory))
                {
                    var boxPhotos = Directory.EnumerateFiles(photosDirectory, $"box{boxId}_*.jpg");
                    foreach (var photo in boxPhotos)
                    {
                        try
                        {
                            File.Delete(photo);
                            return true;
                        }
                        catch (Exception ex)
                        {
                            logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error deleting photo {photo}: {ex.Message}");
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error deleting photos for box {boxId}: {ex.Message}");
                return false;
            }
        });
    }

    public async Task<bool> DeletePhotoAsync(string photoName)
    {
        Guard.IsNotNullOrEmpty(photoName);
        var photoPath = Path.Combine(photosDirectory, photoName);

        return await Task.Run(async () =>
        {
            try
            {
                // Check if the specified path exists and corresponds to a file.
                if (File.Exists(photoPath))
                {
                    // Optional: Add additional checks here, e.g., check the file extension.
                    if (Path.GetExtension(photoPath).Equals(".jpg", StringComparison.OrdinalIgnoreCase))
                    {
                        try
                        {
                            File.Delete(photoPath);
                            Console.WriteLine($"Photo {photoName} successfully deleted.");
                            return true;
                        }
                        catch (Exception ex)
                        {
                            await logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error deleting photo {photoName}: {ex.Message}");
                        }
                    }
                    else
                    {
                        await logger.LogErrorAsync(AppLogger.LogLevel.Error, $"The file {photoName} can't be found.");
                    }
                }
                else
                {
                    await logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Photo {photoName} does not exist.");
                }
            }
            catch (Exception ex)
            {
                await logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error deleting photo: {ex.Message}");
            }
            return false;
        });
    }

    // Get statistics for photos (total size is in Ko)
    public async Task<(int photoCount, long totalSize)> GetPhotosStatsAsync()
    {
        return await Task.Run(() =>
        {
            var photoCount = 0;
            long totalSize = 0;

            try
            {
                if (!Directory.Exists(photosDirectory))
                {
                    logger.LogErrorAsync(AppLogger.LogLevel.Error, "Photos directory does not exist.");
                    return (photoCount, totalSize);
                }

                var photoFiles = Directory.GetFiles(photosDirectory, "*.jpg", SearchOption.AllDirectories);
                photoCount = photoFiles.Length;

                totalSize = photoFiles.Select(file => new FileInfo(file)).Select(fileInfo => fileInfo.Length).Sum() / 1024;
            }
            catch (Exception ex)
            {
                logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error getting photos statistics: " + ex.Message);
                return (-1, -1);
            }

            return (photoCount, totalSize);
        });
    }

    public async Task<List<string>> GetAllImagePathsAsync(bool fullPath = true)
    {
        try
        {
            return await Task.Run(() =>
            {
                if (!Directory.Exists(photosDirectory))
                {
                    // If the directory does not exist, return an empty list or null depending on your application logic.
                    return [];
                }

                // Get all .jpg files in the specified directory.
                // Adjust the search pattern if necessary to include other types of images.
                var imageFiles = Directory.GetFiles(photosDirectory, "*.jpg", SearchOption.AllDirectories);

                return fullPath ? [.. imageFiles] : imageFiles.Select(file => Path.GetFileName(file)).ToList();
            });
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error getting all image paths: " + ex.Message);
            return [];
        }
    }

    public Task<string> GetPhotoPathAsync()
    {
        return Task.FromResult(photosDirectory);
    }
    #endregion

    #region For Testing purpose
    // For testing & maintenance purpose

    // Reset the database and delete all photos
    public async Task ResetDatabaseAndImagesAsync()
    {
        if (database !=null)
        {
            await database.CloseAsync();
        }

        // Delete the database file
        try
        {
            File.Delete(dbPath);
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error,$"An error occurred while deleting the database: {ex.Message}");
            throw;
        }

        try
        {
            database = new SQLiteAsyncConnection(dbPath, Flags);
        }
        catch (Exception ex)
        {
            await logger.LogErrorAsync(AppLogger.LogLevel.Error, "Error SQLite creating database: " + ex.Message);
            IsInitialized = false;
            return;
        }

        await CreateTablesAsync(); // Recreate tables

        // Delete all photos
        if (Directory.Exists(photosDirectory))
        {
            Directory.Delete(photosDirectory, true); // true suppresses all files in subdirectories
        }

        // recreate photos directory
        Directory.CreateDirectory(photosDirectory);
    }

    // Populate the database with test data and generate test images
    public async Task PopulateDatabaseAndImagesWithTestDataAsync()
    {
        var syllables = new List<string> { "lo", "rem", "ip", "sum", "do", "lor", "sit", "a", "met", "con", "sec", "te", "tur", "ad", "i", "pis", "cing", "e", "lit", "sed", "do", "eius", "mod", "tem", "por", "in", "ci", "di", "dunt", "ut", "la", "bo", "re", "et", "do", "lo", "re", "mag", "na", "a", "li", "qua" };
        const int MaxItems = 30;
        var random = new Random();
        // add test data to the database
        for (var i = 1; i <= MaxItems; i++)
        {
            var randomWord = string.Concat(syllables[random.Next(syllables.Count)], syllables[random.Next(syllables.Count)], syllables[random.Next(syllables.Count)]);
            await database.InsertAsync(new Box { Number = i, Description = $"Box {randomWord} {i}" });
            randomWord = string.Concat(syllables[random.Next(syllables.Count)], syllables[random.Next(syllables.Count)], syllables[random.Next(syllables.Count)]);
            await database.InsertAsync(new Category { Name = $"{randomWord} {i}" });
        }

        // add BoxCat relationships
        for (var i = 1; i <= MaxItems*4; i++)
        {
            var boxCat = new BoxCat { BoxId = i % MaxItems, CatId = random.Next(MaxItems)+1 };
            await database.InsertAsync(boxCat);
        }

        // generate test images
        Directory.CreateDirectory(photosDirectory); // S'assurer que le répertoire existe

        for (var i = 1; i <= MaxItems*2; i++)
        {
            var bn = i % MaxItems;
            if (i==0) bn = 1;
            var photoPath = Path.Combine(photosDirectory, $"box{bn}_bigbazar.jpg");
            await CreateTestImageSkiaSharpAsync(photoPath);
        }
    }

    private static SKColor RandomSkColor()
    {
        var rnd = new Random();
        return new SKColor((byte)rnd.Next(256), (byte)rnd.Next(256), (byte)rnd.Next(256));
    }

    private static int RandomNumber(int min, int max)
    {
        var rnd = new Random();
        return rnd.Next(min, max);
    }

    private async Task CreateTestImageSkiaSharpAsync(string imagePath)
    {
        Guard.IsNotNullOrEmpty(imagePath);
        const int width = 1280; // HD Dimension
        const int height = 720; // HD Dimension

        await Task.Run(() =>
        {

            using (var bitmap = new SKBitmap(width, height))
            using (var canvas = new SKCanvas(bitmap))
            {
                canvas.Clear(RandomSkColor());

                for (var i = 0; i < 10; i++) // Dessiner 10 lignes
                {
                    var paint = new SKPaint
                    {
                        Style = SKPaintStyle.Stroke,
                        StrokeWidth = RandomNumber(2, 11), // Randomise entre 2 et 10 inclus
                        Color = RandomSkColor()
                    };
                    var startPoint = new SKPoint(RandomNumber(0, width), RandomNumber(0, height));
                    var endPoint = new SKPoint(RandomNumber(0, width), RandomNumber(0, height));
                    canvas.DrawLine(startPoint, endPoint, paint);
                }

                using (var image = SKImage.FromBitmap(bitmap))
                using (var data = image.Encode(SKEncodedImageFormat.Jpeg, 100))
                {
                    using (var stream = File.OpenWrite(imagePath))
                    {
                        data.SaveTo(stream);
                    }
                }
            }
        });
    }
    #endregion


}
