﻿using System.Collections.ObjectModel;
using System.Reflection;
using BigBazar.Models;
using CommunityToolkit.Mvvm.ComponentModel;


namespace BigBazar.ViewModels;

public partial class GalleryPageViewModel : BaseViewModel
{
    public GalleryPageViewModel() : base()
    {
        Photos = new ObservableCollection<Photo>();
        LoadPhotos();
    }

    [ObservableProperty]
    private ObservableCollection<Photo> photos;

    private void LoadPhotos()
    {
        var imagesPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Resources", "Images");
        var imageFiles = Directory.GetFiles(imagesPath, "*.jpg").OrderBy(f => f);

        foreach (var file in imageFiles)
        {
            Permissions.Photos.Add(new Photo { ImagePath = file, DisplayName = Photo.ExtractDisplayName(file) });
        }
    }
}