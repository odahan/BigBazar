﻿using BigBazar.Views;

namespace BigBazar
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute("BoxDetail", typeof(BoxPage));
            Routing.RegisterRoute("CatSelection", typeof(CatSelectionPage));
        }
    }
}
