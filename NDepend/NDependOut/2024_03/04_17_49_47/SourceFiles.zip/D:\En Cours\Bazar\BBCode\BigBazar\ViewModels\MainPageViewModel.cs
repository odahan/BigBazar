﻿#nullable disable
using BigBazar.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace BigBazar.ViewModels;

public partial class MainPageViewModel : BaseViewModel
{
    private readonly IDataService dataService;

    // constructor
    public MainPageViewModel(IDataService data) : base()
    {
        dataService = data;
        Title = "Big Bazar";
#if DEBUG
        debugMode = true;
#endif
    }

    [ObservableProperty]
    private bool debugMode = false;

    [RelayCommand]
    private async Task About()
    {
        await Shell.Current.GoToAsync("//About");
    }

    [RelayCommand]
    private async Task AddBox()
    {

    }

    [RelayCommand]
    private async Task BoxList()
    {
        await Shell.Current.GoToAsync("//BoxList");
    }

    [RelayCommand]
    private async Task Cats()
    {
        await Shell.Current.GoToAsync("//Categories");
    }

    [RelayCommand]
    private async Task ShowGallery()
    {
        await Shell.Current.GoToAsync("//Gallery");
    }


#if DEBUG
    [RelayCommand]
    private async Task NewTestDb()
    {
        await dataService.ResetDatabaseAndImagesAsync();
        await dataService.PopulateDatabaseAndImagesWithTestDataAsync();
    }
 #endif
}