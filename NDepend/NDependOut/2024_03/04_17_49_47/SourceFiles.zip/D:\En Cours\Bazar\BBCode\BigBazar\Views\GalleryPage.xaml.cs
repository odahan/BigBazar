namespace BigBazar.Views;

public partial class GalleryPage : ContentPage
{
	public GalleryPage()
	{
		InitializeComponent();
	}
}