﻿#nullable disable
using System;
using System.IO;
using System.Text.RegularExpressions;

namespace BigBazar.Models;


public class Photo(string imagePath)
{
    public string ImagePath { get; set; } = imagePath;
    public string DisplayName { get; set; } = ExtractDisplayName(imagePath);

    public static string ExtractDisplayName(string imagePath)
    {
        var fileName = Path.GetFileNameWithoutExtension(imagePath);
        var regex = new Regex(@"box(\d+)_(\d+)");
        var match = regex.Match(fileName);

        if (!match.Success) return fileName;
        var boxNumber = match.Groups[1].Value;
        var photoNumber = match.Groups[2].Value;
        return $"{boxNumber}/{photoNumber}";

    }
}