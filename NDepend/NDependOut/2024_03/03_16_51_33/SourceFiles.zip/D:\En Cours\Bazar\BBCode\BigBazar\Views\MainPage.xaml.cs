﻿using BigBazar.ViewModels;

namespace BigBazar.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage(MainPageViewModel viewModel)
        {
            InitializeComponent();
            BindingContext = viewModel;
        }


    }

}
