﻿#nullable disable
using SQLite;

namespace BigBazar.Models;

public class Box
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    [Unique]
    public int Number { get; set; }

    public string Description { get; set; }
}