﻿#nullable disable
using BigBazar.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace BigBazar.ViewModels;

public partial class MainPageViewModel : BaseViewModel
{

    // constructor
    public MainPageViewModel() : base()
    {
        Title = "Big Bazar";
    }


    [RelayCommand]
    private async Task About()
    {
      await Shell.Current.GoToAsync("//About");
    }

    [RelayCommand]
    private async Task Logs()
    {
        await Shell.Current.GoToAsync("//Logs");
    }

    [RelayCommand]
    private async Task AddBox()
    {
        
    }

    [RelayCommand]  
    private async Task Cats()
    {
        await Shell.Current.GoToAsync("//Categories");
    }
}