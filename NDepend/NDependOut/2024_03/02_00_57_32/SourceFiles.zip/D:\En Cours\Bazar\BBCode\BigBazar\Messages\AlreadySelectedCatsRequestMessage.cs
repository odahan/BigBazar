﻿#nullable disable
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace BigBazar.Messages;

public class AlreadySelectedCatsRequestMessage : RequestMessage<List<int>>
{
    
}