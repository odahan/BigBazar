﻿#nullable disable
using BigBazar.Messages;
using BigBazar.Models;
using BigBazar.Services;
using BigBazar.Views;
using CommunityToolkit.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Microsoft.Maui.Controls.Xaml.Internals;

namespace BigBazar.ViewModels;

public partial class BoxListPageViewModel : BaseViewModel
{
    readonly IDataService dataService;

    public BoxListPageViewModel(IDataService service) : base()
    {
        Guard.IsNotNull(service);
        Title = "Box List";
        dataService = service;
        LoadDataAsync();
        WeakReferenceMessenger.Default.Register<BoxListDataModifiedMessage>(this, (recipient, message) =>
        {
            // var tuple = (Tuple<Box, int>)message.MessageData;
            if (message.ViewModelName == nameof(BoxListPageViewModel))
                LoadDataAsync();
        });
    }

    private async void LoadDataAsync()
    {
        SearchResults = await dataService.GetBoxesAsync();
    }


    private CancellationTokenSource cts;

    [RelayCommand]
    private async Task PerformSearch(string text)
    {
        cts?.Cancel();
        cts = new CancellationTokenSource();

        try
        {
            await Task.Delay(500, cts.Token); // Wait for the user to stop typing

            if (string.IsNullOrEmpty(text))
                SearchResults = await dataService.GetBoxesAsync();
            else
            {
                IsBusy = true;
                try
                {
                    SearchResults = await dataService.SearchBoxesDescAsync(text);
                }

                finally
                { IsBusy = false; }
            }
        }
        catch (TaskCanceledException)
        {
            // Ignore this exception
        }
    }

    [RelayCommand]
    private async Task ItemTapped(Box box)
    {
        Guard.IsNotNull(box);
        await Shell.Current.GoToAsync($"BoxDetail?boxid={box.Id}");
    }

    [ObservableProperty]
    private List<Box> searchResults;


}