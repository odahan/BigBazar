﻿namespace BigBazar.Controls;

public enum PayloadKind
{
    None=0,
    Delete=1,
    Add=2,
    Custom=3
}