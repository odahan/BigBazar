﻿using BigBazar.Services;

namespace BigBazar.Views;

public class BasePage : ContentPage
{
    protected override bool OnBackButtonPressed()
    {
        Device.BeginInvokeOnMainThread(async () =>
        {
            var result = await this.DisplayAlert("Alert!", "Do you really want to exit?", "Yes", "No");
            if (result) System.Environment.Exit(0);
        });
        return true;
    }
}
