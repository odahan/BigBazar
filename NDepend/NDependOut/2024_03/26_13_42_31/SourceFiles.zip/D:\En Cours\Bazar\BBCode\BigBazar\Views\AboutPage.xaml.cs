namespace BigBazar.Views;

public partial class AboutPage : BasePage
{
	public AboutPage()
	{
		InitializeComponent();
	}
}