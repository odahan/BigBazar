﻿namespace BigBazar.Services;

public interface IDeviceOrientationService
{
    void SetOrientationLandscape();
    void RestSetOrientation();
}