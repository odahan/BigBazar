﻿#nullable disable
using CommunityToolkit.Mvvm.ComponentModel;

namespace BigBazar.Models;

[ObservableObject]
public partial class Photo
{
    public Photo()
    {
    }

    public Photo(string imagePath) : this()
    {
        ImagePath = imagePath;
        DisplayName = ExtractDisplayName(imagePath);
    }

    [ObservableProperty]
    private string imagePath;

    [ObservableProperty]
    private string displayName;

    public static string ExtractDisplayName(string imagePath)
    {
        var (nx, ny) = Utils.ImagePathParser.ExtractNumbersAsString(imagePath);
        return $"Box {nx}";
    }
}