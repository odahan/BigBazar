#nullable disable
using BigBazar.Services;
using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class FullScreenPhotoPage : ContentPage
{
    private FullScreenPhotoPageViewModel viewModel;
    public FullScreenPhotoPage()
    {
        InitializeComponent();
        viewModel = new FullScreenPhotoPageViewModel();
        BindingContext = viewModel;
    }

    private IDeviceOrientationService deviceOrientationService;
    private Page pageAppelante;
    private bool resetOrientation;

    public FullScreenPhotoPage(string photoPath, IDeviceOrientationService orientationService, bool resetOrientation) : this()
    {
        this.resetOrientation = resetOrientation;
        deviceOrientationService = orientationService;
        viewModel.PhotoPath = photoPath;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        deviceOrientationService.SetOrientationLandscape();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        if (resetOrientation)
            deviceOrientationService.RestSetOrientation();
    }
}