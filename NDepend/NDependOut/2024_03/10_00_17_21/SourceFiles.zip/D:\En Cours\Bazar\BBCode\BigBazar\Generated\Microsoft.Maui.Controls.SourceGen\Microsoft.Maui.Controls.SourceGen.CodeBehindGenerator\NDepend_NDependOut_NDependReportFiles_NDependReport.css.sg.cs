﻿[assembly: global::Microsoft.Maui.Controls.Xaml.XamlResourceId("BigBazar.NDepend.NDependOut.NDependReportFiles.NDependReport.css", "NDepend/NDependOut/NDependReportFiles/NDependReport.css", null)]
