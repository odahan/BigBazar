#nullable disable
namespace BigBazar.Services
{
    public interface IPathService
    {
        string GetPhotoGalleryPath();
    }
}