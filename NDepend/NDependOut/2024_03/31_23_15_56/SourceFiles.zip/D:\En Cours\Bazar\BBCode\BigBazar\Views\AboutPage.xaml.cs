using System.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace BigBazar.Views;

public partial class AboutPage : BasePage  
{
	public AboutPage()
	{
		InitializeComponent();
		BindingContext = this;
	}

	// expose a property for the current version of the app

	public string Version { get; set; } = AppInfo.VersionString;
	
}