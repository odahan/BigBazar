#nullable disable
using BigBazar.Models;
using BigBazar.Services;
using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class GalleryPage : ContentPage
{
    private IDeviceOrientationService deviceOrientationService;

    public GalleryPage(GalleryPageViewModel viewModel, IDeviceOrientationService orientationService)
    {
        InitializeComponent();
        deviceOrientationService = orientationService;
        BindingContext = viewModel;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        deviceOrientationService.SetOrientationLandscape();
        (BindingContext as GalleryPageViewModel)?.PageAppearingCommand.Execute(null);
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        if (!((GalleryPageViewModel)BindingContext).IsGoingToPhotoDetail) deviceOrientationService.RestSetOrientation();
    }


}