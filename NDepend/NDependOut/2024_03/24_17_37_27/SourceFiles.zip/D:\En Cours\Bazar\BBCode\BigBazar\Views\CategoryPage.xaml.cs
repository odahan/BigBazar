#nullable disable
using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class CategoryPage : BasePage
{
	public CategoryPage(CategoryPageViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
	  
}