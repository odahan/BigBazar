#nullable disable
using BigBazar.Messages;
using BigBazar.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Microsoft.Maui.Controls.PlatformConfiguration;
using Microsoft.Maui.Platform;

namespace BigBazar.Views;

public partial class BoxListPage : ContentPage
{
    public BoxListPage(BoxListPageViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}