﻿#nullable disable
using BigBazar.Messages;
using CommunityToolkit.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Messaging;

namespace BigBazar.ViewModels;

public partial class FullScreenPhotoPageViewModel : BaseViewModel
{

    [ObservableProperty]
    private string photoPath = string.Empty;
}