#nullable disable
using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class CategoryPage : ContentPage
{
	public CategoryPage(CategoryPageViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
	  
}