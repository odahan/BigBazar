﻿#nullable disable
namespace BigBazar.Messages
{
    public class RebuildCatListMessage
    {
        public object Tag { get; set; }
    }
}
