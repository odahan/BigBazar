using System.Collections.ObjectModel;
using BigBazar.Controls;
using BigBazar.Messages;
using BigBazar.Models;
using BigBazar.ViewModels;
using CommunityToolkit.Diagnostics;
using CommunityToolkit.Mvvm.Messaging;

namespace BigBazar.Views;

public partial class BoxPage : ContentPage
{
    public BoxPage(BoxPageViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;

        // subscription to the RebuildCatListMessage
        WeakReferenceMessenger.Default.Register<RebuildCatListMessage>(this, OnRebuildCatListMessageReceived);

        /*
        var pastilleLabel1 = new PastilleLabel
        {
            LabelText = "Outils",
            Payload = 123
        };

        var pastilleLabel2 = new PastilleLabel
        {
            LabelText = "C�bles USB",
            Payload = 124
        };

        var pastilleLabel3 = new PastilleLabel
        {
            LabelText = "Hub USB",
            Payload = 125
        };

        var pastilleLabel4 = new PastilleLabel
        {
            LabelText = "Switch Video",
            Payload = 126
        };

        var pastilleLabel5 = new PastilleLabel
        {
            LabelText = "Modules Synths",
            Payload = 127
        };

        var pastilleLabel6 = new PastilleLabel
        {
            LabelText = "Accessoires Modulaire",
            Payload = 128
        };

        var pastilleLabel7 = new PastilleLabel
        {
            LabelText = "Tournevis pr�cision",
            Payload = 129
        };

        var pastilleLabel8 = new PastilleLabel
        {
            LabelText = "Vid�o Prompter",
            Payload = 130
        };

        var pastilleLabel9 = new PastilleLabel
        {
            LabelText = "APN Canon",
            Payload = 130
        };

        var pastilleLabel10 = new PastilleLabel
        {
            LabelText = "Ajouter",
            PayloadIconKind = PayloadKind.Add,
            BackColorPastille = Colors.Red  
        };

        // Ajouter les contr�les � votre FlexLayout
        flexLayout.Children.Add(pastilleLabel1);
        flexLayout.Children.Add(pastilleLabel2);
        flexLayout.Children.Add(pastilleLabel3);
        flexLayout.Children.Add(pastilleLabel4);
        flexLayout.Children.Add(pastilleLabel5);
        flexLayout.Children.Add(pastilleLabel6);
        flexLayout.Children.Add(pastilleLabel7);
        flexLayout.Children.Add(pastilleLabel8);
        flexLayout.Children.Add(pastilleLabel9);
        flexLayout.Children.Add(pastilleLabel10);*/

    }

    // Event handler for the RebuildCatListMessage
    private void OnRebuildCatListMessageReceived(object recipient, RebuildCatListMessage message)
    {
        Guard.IsNotNull(message);
        Guard.IsAssignableToType(message.Tag, typeof(ObservableCollection<BoxCat>));
        var boxCats = (ObservableCollection<BoxCat>)message.Tag;
        flexLayout.Children.Clear();
        foreach (var boxCat in boxCats)
        {
            var pastilleLabel = new PastilleLabel
            {
                LabelText = boxCat.CatName,
                PayloadIconKind = PayloadKind.Delete,
                Payload = boxCat.IdBoxCat
            };
            flexLayout.Children.Add(pastilleLabel);
        }
        var pastilleLabelAdd = new PastilleLabel
        {
            LabelText = "Add",
            PayloadIconKind = PayloadKind.Add,
            BackColorPastille = Colors.Red
        };
        flexLayout.Children.Add(pastilleLabelAdd);
    }
}