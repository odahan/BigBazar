﻿#nullable disable
using SQLite;

namespace BigBazar.Models;

public class Category
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    [Unique]
    public string Name { get; set; }
}