﻿#nullable disable
using BigBazar.Messages;
using BigBazar.Models;
using BigBazar.Services;
using CommunityToolkit.Diagnostics;
using CommunityToolkit.Maui.Core.Extensions;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using System.Collections.ObjectModel;
using BigBazar.Controls;
using Android.Nfc;

namespace BigBazar.ViewModels;

public partial class BoxPageViewModel : BaseViewModel, IQueryAttributable
{

    public BoxPageViewModel(IDataService service) : base()
    {
        Guard.IsNotNull(service);
        Title = "Box";
        dataService = service;
        WeakReferenceMessenger.Default.Register<PayloadMessage>(this, OnPayloadMessageReceived);
    }

    [ObservableProperty]
    [NotifyPropertyChangedFor("Description")]
    private Box currentBox;

    [ObservableProperty]
    private string description;

    [ObservableProperty]
    private bool isModified;

    private readonly IDataService dataService;

    public ObservableCollection<BoxCatForDisplay> BoxCats { get; set; }

    public async void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        Guard.IsNotNull(query);
        var id = Convert.ToInt32(query["boxid"]);
        CurrentBox = await dataService.GetBoxByIdAsync(id);
        BoxCats = (await dataService.GetCatsForBox(id)).ToObservableCollection();
        Description = CurrentBox.Description;
        IsModified = false;
        WeakReferenceMessenger.Default.Send(new RebuildCatListMessage() { Tag=BoxCats});
    }

    partial void OnDescriptionChanged(string value)
    {
        IsModified = true;
        CurrentBox.Description = value;
    }

    private async void OnPayloadMessageReceived(object recipient, PayloadMessage message)
    {
        var payload = message.Payload;
        var payloadIconKind = message.Kind;
        switch (payloadIconKind)
        {
            case PayloadKind.Add:
                // Add a new BoxCat to the list
                // call to the catselection page. TO BUILD

                WeakReferenceMessenger.Default.Send(new RebuildCatListMessage() { Tag = BoxCats });
                break;
            case PayloadKind.Delete:
                var modified = false;
                for (var i = BoxCats.Count; i >= 0; i--)
                {
                    if (payload != null && BoxCats[i].IdBoxCat == (int)payload)
                    {
                        var boxCatId = (int)payload;
                        BoxCats.RemoveAt(i);
                        await dataService.DeleteBoxCatAsync(boxCatId);
                        modified = true;
                        break;
                    }
                }
                if (modified)
                {
                    BoxCats = (await dataService.GetCatsForBox(CurrentBox.Id)).ToObservableCollection();
                    WeakReferenceMessenger.Default.Send(new RebuildCatListMessage() { Tag = BoxCats });
                }
                break;
            default:
                break;
        }
      
    }

    [RelayCommand]
    public void Save()
    {
        IsBusy = true;
        try
        {
            try
            {
                Guard.IsNotNull(dataService);
                dataService.SaveBoxAsync(CurrentBox);
                WeakReferenceMessenger.Default.Send(new DataModifiedMessage { ViewModelName = nameof(BoxListPageViewModel), MessageData = new Tuple<Box, int>(CurrentBox, currentBox.Id) });
            }
            finally
            {
                IsBusy = false;
            }
            IsModified = false;
        }
        catch (Exception ex)
        {
            Logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error saving Box entity: {ex.Message}");
            IsModified = false;
        }
    }
}