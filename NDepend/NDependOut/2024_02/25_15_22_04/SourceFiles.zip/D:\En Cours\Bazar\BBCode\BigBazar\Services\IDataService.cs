﻿#nullable disable
using BigBazar.Models;

namespace BigBazar.Services;

public interface IDataService
{
    // init
    // ReSharper disable once InconsistentNaming
    bool IsInitialized { get; }

    #region operations for Box entity
    Task<int> SaveBoxAsync(Box box);
    Task<int> DeleteBoxAsync(int boxId);
    Task<List<Box>> GetBoxesAsync();
    Task<Box> GetBoxByIdAsync(int id);
    Task<Box> GetBoxByNumberAsync(int id);
    Task<int> GetLastBoxNumberAsync();
    Task<bool> DeleteBoxByBoxNumber(int boxNumber);
    Task<List<Box>> SearchBoxesDescAsync(string text);
    Box CopyBox(Box originalBox);

    #endregion

    #region operations for Category entity
    Task<int> SaveCategoryAsync(Category category);
    Task<int> DeleteCategoryAsync(int categoryId);
    Task<List<Category>> GetCategoriesAsync();
    Task<Category> GetCategoryByIdAsync(int id);
    Task<List<BoxCatForDisplay>> GetCatsForBox(int boxId);
    #endregion

    #region operations for BoxCat entity
    Task<int> AddBoxCatAsync(BoxCat boxCat);
    Task<int> DeleteBoxCatAsync(int boxCatId);
    Task<List<BoxCat>> GetBoxCatsAsync();
    #endregion

    #region Backup database
    Task<bool> BackupDatabaseAsync();
    #endregion

    #region Photo operations
    Task<string> AddPhotoForBoxAsync(int boxId);
    Task<bool> DeleteAllPhotosForBoxAsync(int boxId);
    Task<bool> DeletePhotoAsync(string photoName);
    Task<(int photoCount, long totalSize)> GetPhotosStatsAsync();
    Task<List<string>> GetAllImagePathsAsync(bool fullPath = true);
    Task<string> GetPhotoPathAsync();
    #endregion

    #region For Init, Maintenance & Testing purpose
    Task CreateTablesAsync();
    Task ResetDatabaseAndImagesAsync();
    Task PopulateDatabaseAndImagesWithTestDataAsync();
    #endregion
}
