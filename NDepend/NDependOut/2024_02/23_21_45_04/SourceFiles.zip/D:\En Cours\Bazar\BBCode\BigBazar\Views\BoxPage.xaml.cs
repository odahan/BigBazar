using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class BoxPage : ContentPage
{
	public BoxPage(BoxPageViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
}