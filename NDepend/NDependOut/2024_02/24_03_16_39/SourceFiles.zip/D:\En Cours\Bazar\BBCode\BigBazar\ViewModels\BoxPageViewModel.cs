﻿#nullable disable
using BigBazar.Messages;
using BigBazar.Models;
using BigBazar.Services;
using CommunityToolkit.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;

namespace BigBazar.ViewModels;

public partial class BoxPageViewModel : BaseViewModel, IQueryAttributable
{

    public BoxPageViewModel(IDataService service) : base()
    {
        Guard.IsNotNull(service);
        Title = "Box";
        dataService = service;
    }

    [ObservableProperty]
    [NotifyPropertyChangedFor("Description")]
    private Box currentBox;

    [ObservableProperty]
    private string description;

    [ObservableProperty]
    private bool isModified;

    private readonly IDataService dataService;

    [ObservableProperty]
    private List<(int CatId, string CatName)> boxCats;

    public async void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        Guard.IsNotNull(query);
        var id = Convert.ToInt32(query["boxid"]);
        CurrentBox = await dataService.GetBoxByIdAsync(id);
        BoxCats= await dataService.GetCatsForBox(id);
        Description = CurrentBox.Description;
        IsModified = false;
    }

    partial void OnDescriptionChanged(string value)
    {
        IsModified = true;
        CurrentBox.Description = value;
    }

    [RelayCommand]
    public void Save()
    {
        IsBusy = true;
        try
        {
            try
            {
                Guard.IsNotNull(dataService);
                dataService.SaveBoxAsync(CurrentBox);
                WeakReferenceMessenger.Default.Send(new DataModifiedMessage { ViewModelName = nameof(BoxListPageViewModel), MessageData=new Tuple<Box, int>(CurrentBox,currentBox.Id) });
            }
            finally
            {
                IsBusy = false;
            }
            IsModified = false;
        }
        catch (Exception ex)
        {
            Logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error saving Box entity: {ex.Message}");
            IsModified = false;
        }
    }
}