using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class LogPage : ContentPage
{
	public LogPage(LogPageViewModel vm)
	{
		InitializeComponent();
		BindingContext = vm;
	}
}