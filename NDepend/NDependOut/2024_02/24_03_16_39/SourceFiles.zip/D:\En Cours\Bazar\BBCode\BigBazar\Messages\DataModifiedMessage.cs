﻿#nullable disable
namespace BigBazar.Messages
{
    public class DataModifiedMessage
    {
        public string ViewModelName { get; set; }
        public object MessageData { get; set; }
    }

}
