﻿#nullable disable
namespace BigBazar.Messages
{
    public class PayloadMessage : IDisposable
    {
        public object Sender { get; set; }
        public object Payload { get; set; }

        private bool disposed = false;

        public PayloadMessage(object sender, object pload)
        {
            Sender = sender;
            Payload = pload;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposed) return;
            if (disposing)
            {
                  Payload = null;
            }
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~PayloadMessage()
        {
            Dispose(false);
        }
    }

}
