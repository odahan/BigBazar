#nullable disable
using BigBazar.Messages;
using CommunityToolkit.Mvvm.Messaging;
using Microsoft.Maui.ApplicationModel;
using System;
using System.Runtime.Versioning;
using CommunityToolkit.Diagnostics;

namespace BigBazar.Controls;

public partial class PastilleLabel : ContentView
{

    public PastilleLabel()
    {
        InitializeComponent();
        BindingContext = this;
        Guard.IsNotNull(Application.Current);
        if (Application.Current?.RequestedTheme == AppTheme.Light)
        {
            var hasValue = Application.Current.Resources.TryGetValue("Gray200", out object theColor);
            if (hasValue)
            {
                BackColorPastille = (Color)theColor;
            }
        }
        else
        {
            var hasValue = Application.Current.Resources.TryGetValue("Gray950", out object theColor);
            if (hasValue)
            {
                BackColorPastille = (Color)theColor;
            }
        }

    }

    public static readonly BindableProperty LabelTextProperty = BindableProperty.Create(
        nameof(LabelText), typeof(string), typeof(PastilleLabel), default(string));

    public static readonly BindableProperty IconSourceProperty = BindableProperty.Create(
        nameof(IconSource), typeof(string), typeof(PastilleLabel), "closecircle.png");

    public static readonly BindableProperty FlashColorProperty = BindableProperty.Create(
        nameof(FlashColor), typeof(Color), typeof(PastilleLabel), Colors.White);

    public static readonly BindableProperty FlashDurationProperty = BindableProperty.Create(
        nameof(FlashDuration), typeof(int), typeof(PastilleLabel), 100);

    public static readonly BindableProperty PayloadProperty = BindableProperty.Create(
        nameof(Payload), typeof(object), typeof(PastilleLabel), null);

    public static readonly BindableProperty BackColorPastilleProperty = BindableProperty.Create(
        nameof(BackColorPastille), typeof(Color), typeof(PastilleLabel), Colors.Black, propertyChanged: OnBackColorPastilleChanged);

    private static void OnBackColorPastilleChanged(BindableObject bindable, object oldValue, object newValue)
    {
        Guard.IsNotNull(bindable);
        var pastilleLabel = (PastilleLabel)bindable;
        pastilleLabel.frameBase.BackgroundColor = (Color)newValue;
    }

    public string LabelText
    {
        get => (string)GetValue(LabelTextProperty);
        set => SetValue(LabelTextProperty, value);
    }

    public string IconSource
    {
        get => (string)GetValue(IconSourceProperty);
        set => SetValue(IconSourceProperty, value);
    }

    public Color FlashColor
    {
        get => (Color)GetValue(FlashColorProperty);
        set => SetValue(FlashColorProperty, value);
    }

    public int FlashDuration
    {
        get => (int)GetValue(FlashDurationProperty);
        set => SetValue(FlashDurationProperty, value);
    }

    public object Payload
    {
        get => (object)GetValue(PayloadProperty);
        set => SetValue(PayloadProperty, value);
    }

    public Color BackColorPastille
    {
        get => (Color)GetValue(BackColorPastilleProperty);
        set => SetValue(BackColorPastilleProperty, value);
    }

    private async void ImageButton_Clicked(object sender, EventArgs e)
    {
        Guard.IsNotNull(sender);
        var originalColor = frameBase.BackgroundColor;
        frameBase.BackgroundColor = FlashColor;
        await Task.Delay(FlashDuration);
        frameBase.BackgroundColor = originalColor;
        var message = new PayloadMessage(this, Payload);
        WeakReferenceMessenger.Default.Send(message);
        
    }
}