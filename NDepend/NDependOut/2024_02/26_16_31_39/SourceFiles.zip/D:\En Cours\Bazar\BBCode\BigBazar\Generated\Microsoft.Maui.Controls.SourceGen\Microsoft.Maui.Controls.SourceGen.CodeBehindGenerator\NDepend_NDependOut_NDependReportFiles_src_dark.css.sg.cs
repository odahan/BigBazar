﻿[assembly: global::Microsoft.Maui.Controls.Xaml.XamlResourceId("BigBazar.NDepend.NDependOut.NDependReportFiles.src.dark.css", "NDepend/NDependOut/NDependReportFiles/src/dark.css", null)]
