﻿#nullable disable
using BigBazar.Messages;
using BigBazar.Models;
using BigBazar.Services;
using CommunityToolkit.Diagnostics;
using CommunityToolkit.Maui.Core.Extensions;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using System.Collections.ObjectModel;
using BigBazar.Controls;

namespace BigBazar.ViewModels;

public partial class BoxPageViewModel : BaseViewModel, IQueryAttributable
{

    public BoxPageViewModel(IDataService service) : base()
    {
        Guard.IsNotNull(service);
        Title = "Box";
        dataService = service;
        WeakReferenceMessenger.Default.Register<PastillePayloadMessage>(this, OnPayloadMessageReceived);
        WeakReferenceMessenger.Default.Register<CatSelectedMessage>(this, OnCatSelectedMessageReceived);
    }


    [ObservableProperty]
    [NotifyPropertyChangedFor("Description")]
    private Box currentBox;

    [ObservableProperty]
    private string description;

    [ObservableProperty]
    private bool isModified;

    private readonly IDataService dataService;

    public ObservableCollection<BoxCatForDisplay> BoxCats { get; set; }

    public async void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        Guard.IsNotNull(query);
        var id = Convert.ToInt32(query["boxid"]);
        CurrentBox = await dataService.GetBoxByIdAsync(id);
        BoxCats = (await dataService.GetCatsForBox(id)).ToObservableCollection();
        Description = CurrentBox.Description;
        IsModified = false;
        WeakReferenceMessenger.Default.Send(new BoxPageRebuildCatListMessage() { Tag = BoxCats });
    }

    partial void OnDescriptionChanged(string value)
    {
        IsModified = true;
        CurrentBox.Description = value;
    }

    private readonly object locker = new object();
    private bool working = false;
    private async void OnPayloadMessageReceived(object recipient, PastillePayloadMessage message)
    {
        lock (locker)
        {
            if (working)
            {
                return;
            }
            working = true;
        }
        try
        {
            Guard.IsNotNull(message);
            var payload = message.Payload;
            var payloadIconKind = message.Kind;
            switch (payloadIconKind)
            {
                case PayloadKind.Add:
                    // Add a new BoxCat to the list
                    // call to the catselection page. TO BUILD
                    await Shell.Current.GoToAsync("CatSelection");
                    WeakReferenceMessenger.Default.Send(new BoxPageRebuildCatListMessage() { Tag = BoxCats });
                    break;
                case PayloadKind.Delete:
                    var modified = false;
                    for (var i = BoxCats.Count - 1; i >= 0; i--)
                    {
                        if (payload != null && BoxCats[i].IdBoxCat == (int)payload)
                        {
                            var boxCatId = (int)payload;
                            BoxCats.RemoveAt(i);
                            await dataService.DeleteBoxCatAsync(boxCatId);
                            modified = true;
                            break;
                        }
                    }
                    if (modified)
                    {
                        BoxCats = (await dataService.GetCatsForBox(CurrentBox.Id)).ToObservableCollection();
                        WeakReferenceMessenger.Default.Send(new BoxPageRebuildCatListMessage() { Tag = BoxCats });
                    }
                    break;
                default:
                    break;
            }
        }
        finally
        {
            lock (locker) working = false;
        }
    }

    [RelayCommand]
    public void Save()
    {
        IsBusy = true;
        try
        {
            try
            {
                Guard.IsNotNull(dataService);
                dataService.SaveBoxAsync(CurrentBox);
                WeakReferenceMessenger.Default.Send(new BoxListDataModifiedMessage { ViewModelName = nameof(BoxListPageViewModel), MessageData = new Tuple<Box, int>(CurrentBox, currentBox.Id) });
            }
            finally
            {
                IsBusy = false;
            }
            IsModified = false;
        }
        catch (Exception ex)
        {
            Logger.LogErrorAsync(AppLogger.LogLevel.Error, $"Error saving Box entity: {ex.Message}");
            IsModified = false;
        }
    }

    private async void OnCatSelectedMessageReceived(object recipient, CatSelectedMessage message)
    {
        Guard.IsNotNull(message);
        IsBusy = true;
        try
        {
            var selectedCats = message.SelectedCategories;
            foreach (var cat in selectedCats)
            {
                var b = BoxCats.Any(c => c.IdBoxCat == cat.Id);
                if (b) continue;
                var bxc = new BoxCat() { CatId = cat.Id, BoxId = CurrentBox.Id };
                var id = await dataService.SaveBoxCatAsync(bxc);
                var bcf = new BoxCatForDisplay(id, cat.Id, CurrentBox.Id, cat.Name);
                BoxCats.Add(bcf);
                //sort boxcats by catname   
                BoxCats = BoxCats.OrderBy(c => c.CatName).ToObservableCollection();
            }
        }
        finally
        {
            IsBusy = false;
        }
        // send a message to rebuild the visual list
        WeakReferenceMessenger.Default.Send(new BoxPageRebuildCatListMessage() { Tag = BoxCats });
    }
}