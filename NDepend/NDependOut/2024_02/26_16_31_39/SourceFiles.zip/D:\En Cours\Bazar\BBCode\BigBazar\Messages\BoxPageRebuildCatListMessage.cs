﻿#nullable disable
namespace BigBazar.Messages
{
    public class BoxPageRebuildCatListMessage
    {
        public object Tag { get; set; }
    }
}
