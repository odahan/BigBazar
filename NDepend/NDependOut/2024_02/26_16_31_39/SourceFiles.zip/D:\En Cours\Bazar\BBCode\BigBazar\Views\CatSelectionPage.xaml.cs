using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class CatSelectionPage : ContentPage
{
	public CatSelectionPage(CatSelectionPageViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
}