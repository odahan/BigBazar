﻿#nullable disable
using BigBazar.Messages;
using BigBazar.Models;
using BigBazar.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;

namespace BigBazar.ViewModels;

public partial class CatSelectionPageViewModel : BaseViewModel
{
    public CatSelectionPageViewModel(IDataService data) : base()
    {
        Title = "Select Category(ies)";
        dataService = data;
        LoadDataAsync();
    }

    private readonly IDataService dataService;

      [ObservableProperty]
    private List<CategoryForSelection> categoriesToSelect = [];

    private async void LoadDataAsync()
    {
        IsBusy = true;
        try
        {
            var cats  = await dataService.GetCategoriesAsync();
            CategoriesToSelect = cats
                .Select(c => new CategoryForSelection() { Id = c.Id, Name = c.Name, IsSelected = false })
                .OrderBy(c => c.Name)
                .ToList();
        }
        finally { IsBusy = false; }
    }

    [RelayCommand]
    private async Task Cancel()
    {
        await Shell.Current.GoToAsync("..");
    }

    [RelayCommand]
    private async Task Select()
    {
        // créer la liste des éléments sélectionnés
        var selectedCats = CategoriesToSelect
            .Where(c => c.IsSelected)
            .Select(c => new Category() { Id = c.Id, Name = c.Name })
            .ToList();
        
         WeakReferenceMessenger.Default.Send(new CatSelectedMessage(selectedCats));


        await Shell.Current.GoToAsync("..");
    }
}