﻿#nullable disable

namespace BigBazar.Models
{
    using SQLite;

    public class BoxCat
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public int BoxId { get; set; }

        public int CatId { get; set; }
    }

}
