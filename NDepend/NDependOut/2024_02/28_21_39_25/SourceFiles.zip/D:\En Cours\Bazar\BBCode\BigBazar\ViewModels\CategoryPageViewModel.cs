﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BigBazar.Models;
using BigBazar.Services;
using CommunityToolkit.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace BigBazar.ViewModels
{
    public partial class CategoryPageViewModel : BaseViewModel
    {
        private readonly IDataService dataService;
        private readonly IDialogService dialogService;
        public CategoryPageViewModel(IDataService data, IDialogService dialog) : base()
        {
            Title = "Categoryies";
            dataService = data;
            dialogService = dialog;
            LoadDataAsync();
        }

        [ObservableProperty]
        private ObservableCollection<Category> categories = [];

        [ObservableProperty]
        private Category selectedCategory;


        private async void LoadDataAsync()
        {
            IsBusy = true;
            try
            {
                Categories = new ObservableCollection<Category>(await dataService.GetCategoriesAsync());
            }
            finally { IsBusy = false; }
        }

        [RelayCommand]
        private async Task ValidateChange()
        {
            if (SelectedCategory == null) return;   
            await dataService.SaveCategoryAsync(SelectedCategory);
        }
    }

        [RelayCommand]
        private async Task AddCategory()
        {
            var newCategory = new Category();
        }

        [RelayCommand]
        private async Task QuiPage()
        {
          // navigate back with the shell
          await Shell.Current.GoToAsync("..");
        }
    }
}
