﻿#nullable disable
using BigBazar.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace BigBazar.ViewModels;

public partial class MainPageViewModel : BaseViewModel
{

    // constructor
    public MainPageViewModel(IDataService dataService) : base()
    {
        Title = "Big Bazar";
        this.dataService = dataService;
    }

    [ObservableProperty]
    private string logs;

    private IDataService dataService { get; }

    [RelayCommand]
    private async Task GoAboutPage()
    {
      await dataService.PopulateDatabaseAndImagesWithTestDataAsync();
    }

    [RelayCommand]
    private async Task GetLog()
    {
        Logs = await Logger.GetCurrentLogContentAsync();
    }

    [RelayCommand]
    private async Task DeleteLogs()
    {
        await Logger.DeleteAllLogs();
        Logs = string.Empty;
    }
}