#nullable disable
using BigBazar.ViewModels;

namespace BigBazar.Views;

public partial class CategoryPage : ContentPage
{
	public CategoryPage(CategoryPageViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}

    private void Entry_TextChanged(object sender, TextChangedEventArgs e)
    {
		ValidateEntry.IsEnabled = true;
    }

    private void ValidateEntry_Clicked(object sender, EventArgs e)
    {
        ValidateEntry.IsEnabled = false;
    }
}